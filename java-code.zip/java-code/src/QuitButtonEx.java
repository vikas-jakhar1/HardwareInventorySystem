import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import java.awt.EventQueue;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class QuitButtonEx extends JFrame {

    public QuitButtonEx() {

        initUI();
    }
    private void cusCancelBtnActionPerformed()
    {
        asd();
    }
    private void initUI() {

        var quitButton = new JButton("Run");

        quitButton.addActionListener((event) -> cusCancelBtnActionPerformed());

        createLayout(quitButton);

        setTitle("Quit button");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    private void createLayout(JComponent... arg) {

        var pane = getContentPane();
        var gl = new GroupLayout(pane);
        pane.setLayout(gl);

        gl.setAutoCreateContainerGaps(true);

        gl.setHorizontalGroup(gl.createSequentialGroup()
                .addComponent(arg[0])
        );

        gl.setVerticalGroup(gl.createSequentialGroup()
                .addComponent(arg[0])
        );
    }
    public static String makeVbScript(String vbClassName, String[] propNames) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < propNames.length; i++) {
            if (i < propNames.length - 1) {
                sb.append(propNames[i]).append(",");
            } else {
                sb.append(propNames[i]);
            }
        }
        String colNameString = sb.toString();
        sb.setLength(0);

        sb.append("Set objWMIService = GetObject(\"winmgmts:\\\\.\\root\\cimv2\")").append("\n");
        sb.append("Set colItems = objWMIService.ExecQuery _ ").append("\n");
        sb.append("(\"Select ").append(colNameString).append(" from ").append(vbClassName).append("\") ").append("\n");
        sb.append("For Each objItem in colItems ").append("\n");
        for (String propName : propNames) {
            sb.append("    Wscript.Echo objItem.").append(propName).append("\n");
        }
        sb.append("Next ").append("\n");
        return sb.toString();
    }
    public static String name[]=new String[4];

    public static void printComputerSystemProductInfo() {

        String vbClassName = "Win32_ComputerSystemProduct";
        String[] propNames = new String[] { "Name", "UUID"};

        String vbScript = makeVbScript(vbClassName, propNames);

        try {

            File file = File.createTempFile("vbsfile", ".vbs");

            FileWriter fw = new FileWriter(file);
            fw.write(vbScript);
            fw.close();


            Process p = Runtime.getRuntime().exec("cscript //NoLogo " + file.getPath());


            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

            Map<String, String> map = new HashMap<String, String>();
            String line;
            int i = 0;
            while ((line = input.readLine()) != null) {
                if (i >= propNames.length) {
                    break;
                }
                String key = propNames[i];

                map.put(key, line);
                
                i++;
            }
            input.close();
            //
            int ii=0;

            for (String propName : propNames) {
                System.out.println(propName + " : " + map.get(propName));
                name[ii]=map.get(propName);
                ii++;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void printComputerSystemProductInfo1() {

        String vbClassName1 = "Win32_Keyboard";
        String[] propNames1 = new String[] { "Caption", "Layout"};

        String vbScript = makeVbScript(vbClassName1, propNames1);

        try {

            File file = File.createTempFile("vbsfile", ".vbs");

            FileWriter fw = new FileWriter(file);
            fw.write(vbScript);
            fw.close();


            Process p = Runtime.getRuntime().exec("cscript //NoLogo " + file.getPath());


            BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));

            Map<String, String> map = new HashMap<String, String>();
            String line;
            int i = 0;
            while ((line = input.readLine()) != null) {
                if (i >= propNames1.length) {
                    break;
                }
                String key = propNames1[i];

                map.put(key, line);
                //map.put(key1, line);
                i++;
            }
            input.close();
            //
            int ii=0;

            for (String propName1 : propNames1) {
                System.out.println(propName1 + " : " + map.get(propName1));
                name[ii]=map.get(propName1);
                ii++;
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void asd() {
        printComputerSystemProductInfo();
        printComputerSystemProductInfo1();
        long diskSize = new File("/").getTotalSpace();
        String userName = System.getProperty("user.name");
        long maxMemory = Runtime.getRuntime().maxMemory();
        long memorySize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
        int f= (int) (diskSize/1024);
        int g=(int) (f/1024);
        int h=(int)(g/1024);
        System.out.println("Size of C:="+h+" GBytes");
        System.out.println("User Name="+userName);
        int c= (int) (memorySize/1024);
        int d=(int) (c/1024);
        int e =(int)(d/1024);

        System.out.println("RAM Size="+e+" GBytes");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con= DriverManager.getConnection("jdbc:mysql://db4free.net:3306/hardware_11","hardware1","hardware11");
            Statement stmt=con.createStatement();

            String qry="insert into hardwarein values('"+name[0]+"','"+name[1]+"','"+name[2]+"','"+name[3]+"','"+h+"','"+e+"')";
            int i=stmt.executeUpdate(qry);
            if(i>0) {
                System.out.println("Records Inserted...");

            }

            con.close();
        }
        catch(Exception aa)
        {
            System.out.println(aa);
        }
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            var ex = new QuitButtonEx();
            ex.setVisible(true);
        });
    }
}
